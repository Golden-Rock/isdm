
    <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button"><i class="zmdi zmdi-apps"></i>
        <!-- <div class="notify">
            <span class="heartbit"></span>
            <span class="point"></span>
        </div> -->
        </a>
        <ul class="dropdown-menu pullDown">
            <li class="header">Raccourcis</li>
            <li class="body">
                <div class="p-2">
                    <div class="row g-0">
                        <div class="col">
                            <a class="dropdown-icon-item" href="#">
                                <img src="assets/images/brands/dossier.png" width="30px" height="30px" alt="dossier">
                                <span>Dossiers </span>
                            </a>
                        </div>
                        <div class="col">
                            <a class="dropdown-icon-item" href="#">
                                <img src="assets/images/brands/archive.png" width="30px" height="30px" alt="archives">
                                <span>Archives </span>
                            </a>
                        </div>
                        <div class="col">
                            <a class="dropdown-icon-item" href="#">
                                <img src="assets/images/brands/member.png" width="30px" height="30px" alt="member">
                                <span>Membres</span>
                            </a>
                        </div>
                    </div>

                    <div class="row g-0">
                        <div class="col">
                            <a class="dropdown-icon-item" href="#">
                                <img src="assets/images/brands/client.png" width="30px" height="30px" alt="client">
                                <span>Clients</span>
                            </a>
                        </div>
                        <div class="col">
                            <a class="dropdown-icon-item" href="#">
                                <img src="assets/images/brands/kpi.png" width="30px" height="30px" alt="kpi">
                                <span>KPI</span>
                            </a>
                        </div>
                        <div class="col">
                            <a class="dropdown-icon-item" href="home">
                                <img src="assets/images/brands/hom.png" width="30px" height="30px" alt="home">
                                <span>Accueil</span>
                            </a>
                        </div>
                    </div>
                </div>
            </li>
            <!-- <li class="footer"><a href="javascript:void(0);">View All</a></li> -->
        </ul>
    </li>