<!-- <div class="page-loader-wrapper">
    <div class="loader">
        <div class="m-t-30"><img class="zmdi-hc-spin" src="assets/images/logo/icone.png" width="50" height="48" alt="yemak"></div>
        <p>Yemak Wellness...</p>        
    </div>
</div> -->